#include "Elemento.h"

Elemento::Elemento(std::string nombre, int cantidad): _nombre(nombre), _cantidad(cantidad), _siguiente(NULL)
{
}
